<?php

namespace App\Context;

interface Reader
{
  public function read();
}
