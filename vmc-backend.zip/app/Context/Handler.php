<?php

namespace App\Context;

interface Handler
{
  public function handle();
}
