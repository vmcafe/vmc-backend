<?php

return [
    'ttl' => (int)env("JWT_TTL", "43800")
];